<?php 
/*
	$_SESSION["queryListaServicios2"] = null; 
	$_SESSION["queryListaServicios2"."Check"] = true; 
	$_SESSION["queryListaPaquetes"] = null; 
	$_SESSION["queryListaPaquetes"."Check"] = true; 
	$_SESSION["queryListaClientes"] = null; 
	$_SESSION["queryListaClientes"."Check"] = true; 
	$_SESSION["queryListaNacionalidades"] = null; 
	$_SESSION["queryListaNacionalidades"."Check"] = true; 
	$_SESSION["queryListaUsuarios"] = null; 
	$_SESSION["queryListaUsuarios"."Check"] = true; 
	$_SESSION["queryListaOperacionesLog"] = null; 
	$_SESSION["queryListaOperacionesLog"."Check"] = true; 
	$_SESSION["queryListaTablasLog"] = null; 
	$_SESSION["queryListaTablasLog"."Check"] = true; 
	$_SESSION["queryListaRoles"] = null; 
	$_SESSION["queryListaRoles"."Check"] = true; 
	$_SESSION["queryListaProveedores"] = null; 
	$_SESSION["queryListaProveedores"."Check"] = true; 
	$_SESSION["queryListaHoteles"] = null; 
	$_SESSION["queryListaHoteles"."Check"] = true; 
	$_SESSION["queryListaServicios"] = null; 
	$_SESSION["queryListaServicios"."Check"] = true; 
	$_SESSION["queryConteoServicios"] = null; 
	$_SESSION["queryConteoServicios"."Check"] = true; 
	$_SESSION["queryConteoProveedores"] = null; 
	$_SESSION["queryConteoProveedores"."Check"] = true; 
	$_SESSION["queryListaOtrUbi"] = null; 
	$_SESSION["queryListaOtrUbi"."Check"] = true; 
	$_SESSION["queryListaArpUbi"] = null; 
	$_SESSION["queryListaArpUbi"."Check"] = true; 
	$_SESSION["queryListaMueUbi"] = null; 
	$_SESSION["queryListaMueUbi"."Check"] = true;
	$_SESSION["queryVuelosSearch2IN"] = null; 
	$_SESSION["queryVuelosSearch2IN"."Check"] = true;
	$_SESSION["queryVuelosSearch2OUT"] = null; 
	$_SESSION["queryVuelosSearch2OUT"."Check"] = true;
*/

	//echo"<script> alert('SESSION asignele null'); </script>";
?>