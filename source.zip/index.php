<?php
include "library/funciones.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<html>
	<head>
		<meta charset=utf-8 />	
        <title><?php include "library/title.php"; ?></title>
		<?php $xajax->printJavascript(); ?>
		<LINK REL="SHORTCUT ICON" HREF="images/favicon.ico">
		<link media="screen" rel="stylesheet" href="colorbox.css" />
		<link rel=stylesheet type="text/css" href="library/styles2.css">
		<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script> -->
		<script src="colorbox/jquery.min.js"></script>
		<script src="colorbox/jquery.colorbox.js"></script>		
		<script> 
			<?php
				if ($_SESSION["language"] == 'en'){
					echo"var language = 'library/lang_en.xml'; ";
				}
				else{
					echo"var language = 'library/lang_es.xml'; ";
				} 
				
			?>
		</script>
		<script type="text/javascript" src="script.js"></script>
		<script type='text/JavaScript' src='scw.js'></script>
		
    </head>
    <body bottommargin="0px" leftmargin="0px" marginheight="0px" marginwidth="0px" rightmargin="0px" topmargin="0px" bgcolor="#EAEAEA">
        <center>
            <table border="0" style="border: 2px solid #565656; border-top: 0px" cellpadding="0px" cellspacing="0px" bgcolor="#FFFFFF" height="100%" width="1050px">
                <tr>
                    <td>
                        <img src="images/header.jpg" border="0" width="1050px" height="117px" alt="">
                    </td>
                </tr>
                <tr>
<!--                    <td background="images/menu_back.gif">-->
                    <td>
                        <?php
                            include "library/menu.php";
                        ?>
                    </td>
                </tr>
                

                <tr>
                    <td height="100%" valign="top">
                        <table border="0" width="100%" cellpadding="0px" cellspacing="0px">
                            <tr>
                                <td width="1%" valign="center" align ="left">&nbsp;
                                    
                                </td>
                                <td width="98%" align ="left">
                                    <?php
                                        include "library/header.php";
                                    ?>
                                    <?php
                                        include "library/window.php";
                                    ?>
                                </td>
                                <td width="1%">&nbsp;
                                    
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>


				<?php
					if($reserva == true)
						include "library/botonesReserva.php";
				?>
										
                <tr>
                    <td background="images/footer.gif" height="38px">
                        <?php
                            include "library/footer.php";
                        ?>
                    </td>
                </tr>
            </table>
            <br>
        </center>

        <?php
            include "library/footer_end.php";
        ?>     
    </body>
</html>