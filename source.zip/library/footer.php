<table border="0" width="100%" cellpadding="0px" cellspacing="0px">
    <tr>
        <td width="50%" style="padding: 5px; color: #ffffff">&copy; Copyright 2018, Gesti&oacute;n Tur&iacute;stica. Todos los derechos reservados.</td>
        <td width="50%" style="padding: 5px" align="right"><img src="images/xajax_powered.png" border="0" alt=""></td>

    </tr>
</table>