<?php 
$alpha = array();
$alpha[1] = "A";
$alpha[2] = "B";
$alpha[3] = "C";
$alpha[4] = "D";
$alpha[5] = "E";
$alpha[6] = "F";
$alpha[7] = "G";
$alpha[8] = "H";
$alpha[9] = "I";
$alpha[10] = "J";
$alpha[11] = "K";
$alpha[12] = "L";
$alpha[13] = "M";
$alpha[14] = "N";
$alpha[15] = "O";
$alpha[16] = "P";
$alpha[17] = "Q";
$alpha[18] = "R";
$alpha[19] = "S";
$alpha[20] = "T";
$alpha[21] = "U";
$alpha[22] = "V";
$alpha[23] = "W";
$alpha[24] = "X";
$alpha[25] = "Y";
$alpha[26] = "Z";
$alpha[27] = "AA";
$alpha[28] = "AB";
$alpha[28] = "AC";
$alpha[28] = "AD";

function getColumnName($pNum){
	global $alpha;
	return $alpha[$pNum];
}

?>
