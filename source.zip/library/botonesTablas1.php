<tr>
	<td height="38px">
		<center>
		<input type="button" id="btnIngresarTabla" name="btnIngresarTabla" value="<?php printValueXML('formTablas','btnIngresar') ?>" onClick="ingresarEnTabla();" class="boton btnTablas2" onmouseover="className='botonHover btnTablas2'" onmouseout="className='boton btnTablas2'" />&nbsp;&nbsp;&nbsp;
		<input type="button" id="btnGuardarTabla" name="btnGuardarTabla" value="<?php printValueXML('formTablas','btnGuardar') ?>" onclick="registrarEnTabla();" disabled="disabled" class="boton btnTablas2" onmouseover="className='botonHover btnTablas2'" onmouseout="className='boton btnTablas2'" />&nbsp;&nbsp;&nbsp;
