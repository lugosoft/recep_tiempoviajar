		<input type="button" id="btnActualizarTabla" name="btnActualizarTabla" value="<?php printValueXML('formTablas','btnActualizar') ?>" onclick="actualizarEnTabla();" disabled="disabled" class="boton btnTablas2" onmouseover="className='botonHover btnTablas2'" onmouseout="className='boton btnTablas2'" />&nbsp;&nbsp;&nbsp;
		<input type="button" id="btnRetirarTabla" name="btnRetirarTabla" value="<?php printValueXML('formTablas','btnRetirar') ?>" onclick="retirarEnTabla();" disabled="disabled" class="boton btnTablas2" onmouseover="className='botonHover btnTablas2'" onmouseout="className='boton btnTablas2'" />&nbsp;&nbsp;&nbsp;
		<input type="button" id="btnCancelarTabla" name="btnCancelarTabla" value="<?php printValueXML('formTablas','btnCancelar') ?>" onClick="cancelarEnTabla();" class="boton btnTablas3" onmouseover="className='botonHover btnTablas3'" onmouseout="className='boton btnTablas3'" />
		</center>
	</td>
</tr>
