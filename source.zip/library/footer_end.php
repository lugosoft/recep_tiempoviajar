<div style="font-size: 0.8em; text-align: center; margin-top: 1.0em; margin-bottom: 1.0em;">
    <Strong>Gesti&oacute;n Tur&iacute;stica.</Strong><br>
    Cartagena, (Colombia)<br>
    (5)6745978<br>
</div>

<div style="font-size: 0.8em; text-align: center; margin-top: 1.0em; margin-bottom: 1.0em; color: #C4C2C4;">
    Powered by <a href="mailto:luisgonzalez@ingenieros.com" style="color: #C4C2C4">LuisGonzalez@ingenieros.com</a>
</div>